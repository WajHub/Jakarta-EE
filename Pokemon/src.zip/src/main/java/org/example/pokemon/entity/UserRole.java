package org.example.pokemon.entity;

public enum UserRole {
    ADMIN, USER;

    public static final String ROLE_ADMIN = "admin";
    public static final String ROLE_USER = "user";
}
