package org.example.pokemon.view.config;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.annotation.FacesConfig;

@FacesConfig
@ApplicationScoped
public class ViewConfig {
}

